-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mar 31, 2021 alle 14:32
-- Versione del server: 10.4.14-MariaDB
-- Versione PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `swapbook`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `book`
--

CREATE TABLE `book` (
  `ID_book` int(11) NOT NULL,
  `author` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `publishing_house` varchar(50) NOT NULL,
  `physical_desc` varchar(500) NOT NULL,
  `publishing_year` year(4) NOT NULL,
  `condition` varchar(20) NOT NULL,
  `lenght` float NOT NULL,
  `height` float NOT NULL,
  `width` float NOT NULL,
  `ID_genre` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `book`
--

INSERT INTO `book` (`ID_book`, `author`, `title`, `publishing_house`, `physical_desc`, `publishing_year`, `condition`, `lenght`, `height`, `width`, `ID_genre`) VALUES
(1, 'federico nobile', 'lo hobbit', 'capitello', 'copertina rigida', 2011, 'buone', 5, 5, 5, 1),
(2, 'jayson andal', 'i titani', 'feltrinelli', 'copertina flessibile', 1990, 'usato', 7, 7, 7, 2),
(3, 'Simone Ramello', 'Il signore degli Anelli', 'valmora', 'rigida', 2002, 'nuovo', 5, 5, 5, 1),
(4, 'JK rowling', 'Harry potter', 'sant\'anna', 'normale', 2001, 'usato', 6, 6, 6, 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `chat`
--

CREATE TABLE `chat` (
  `ID_chat` int(11) NOT NULL,
  `start_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `ID_post` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `genre`
--

CREATE TABLE `genre` (
  `ID_genre` int(11) NOT NULL,
  `genre_desc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `genre`
--

INSERT INTO `genre` (`ID_genre`, `genre_desc`) VALUES
(1, 'giallo'),
(2, 'thriller');

-- --------------------------------------------------------

--
-- Struttura della tabella `location`
--

CREATE TABLE `location` (
  `ID_location` int(11) NOT NULL,
  `city` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `location`
--

INSERT INTO `location` (`ID_location`, `city`, `province`) VALUES
(1, 'Torino', 'Torino'),
(2, 'Orbassano', 'Torino'),
(3, 'Nichelino', 'Torino'),
(7, 'Poirino', 'Torino');

-- --------------------------------------------------------

--
-- Struttura della tabella `message`
--

CREATE TABLE `message` (
  `ID_message` int(11) NOT NULL,
  `msg_text` varchar(2000) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `ID_writer` int(11) NOT NULL,
  `ID_recepient` int(11) NOT NULL,
  `ID_chat` int(11) NOT NULL,
  `order_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `post`
--

CREATE TABLE `post` (
  `ID_post` int(11) NOT NULL,
  `publishing_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `closing_date` timestamp NULL DEFAULT NULL,
  `description` varchar(1000) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `img_src` varchar(500) NOT NULL,
  `ID_location` int(11) NOT NULL,
  `ID_creator` int(11) NOT NULL,
  `ID_book` int(11) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `post`
--

INSERT INTO `post` (`ID_post`, `publishing_date`, `closing_date`, `description`, `state`, `img_src`, `ID_location`, `ID_creator`, `ID_book`, `price`) VALUES
(1, '2021-01-23 10:04:10', NULL, 'questo è un libro', 1, 'https://images-na.ssl-images-amazon.com/images/I/51q5l-TtOUL._SX320_BO1,204,203,200_.jpg', 1, 1, 1, 5),
(2, '2021-01-23 10:04:10', NULL, 'subito.it', 1, 'https://images-na.ssl-images-amazon.com/images/I/91Bx8Fqx1pL.jpg', 2, 2, 2, 10),
(3, '2021-01-26 20:30:40', NULL, 'questo è un libro', 1, 'https://danbrown.com/wp-content/themes/danbrown/images/db/books.03.jpg', 2, 2, 4, 15),
(4, '2021-01-26 20:31:17', NULL, 'questo è un libro', 1, 'https://upload.wikimedia.org/wikipedia/en/thumb/6/67/Origin_%28Dan_Brown_novel_cover%29.jpg/220px-Origin_%28Dan_Brown_novel_cover%29.jpg', 2, 1, 2, 20),
(6, '2021-01-26 20:32:31', NULL, 'questo è un libro', 1, 'https://kbimages1-a.akamaihd.net/5a536c9a-5dc0-499c-bd0d-95c199a735f4/1200/1200/False/percy-jackson-and-the-greek-heroes.jpg', 2, 1, 1, 41),
(7, '2021-01-26 20:32:52', NULL, 'questo è un libro', 1, 'https://upload.wikimedia.org/wikipedia/en/thumb/e/eb/Percy_Jackson_%26_the_Olympians_The_Lightning_Thief_poster.jpg/220px-Percy_Jackson_%26_the_Olympians_The_Lightning_Thief_poster.jpg', 2, 1, 1, 0),
(8, '2021-01-26 20:33:20', NULL, 'questo è un libro', 1, 'https://m.media-amazon.com/images/M/MV5BMTQ5NDlmZWUtMjIyMC00NzQ3LTg3OWYtMzRkY2FiNzQ0Njc4XkEyXkFqcGdeQXVyNDQ2MTMzODA@._V1_UY1200_CR90,0,630,1200_AL_.jpg', 2, 1, 1, 0),
(9, '2021-01-26 20:34:47', '0000-00-00 00:00:00', 'questo è un libro', 0, 'https://images-na.ssl-images-amazon.com/images/I/91RQ5d-eIqL.jpg', 1, 1, 1, 0),
(10, '2021-01-26 20:35:11', NULL, 'questo è un libro', 1, 'https://img.ibs.it/images/8010312105845_0_221_0_75.jpg', 2, 1, 2, 0),
(11, '2021-01-27 15:53:47', NULL, 'questo è un libro', 1, 'https://images-na.ssl-images-amazon.com/images/I/718wyqD+i5L.jpg', 1, 1, 1, 0),
(12, '2021-01-27 15:53:47', NULL, 'questo è un libro', 1, 'https://images-na.ssl-images-amazon.com/images/I/81w8kaYfvkL.jpg', 2, 2, 2, 0),
(13, '2021-01-27 15:53:47', NULL, 'questo è un libro', 1, 'https://media.adelphi.it/spool/77b173d7c2983595bb4f5e9bee9b959b_w_h_mw600_mh900_cs_cx_cy.jpg', 1, 5, 3, 0),
(14, '2021-01-27 15:53:47', NULL, 'questo è un libro', 1, 'https://images-na.ssl-images-amazon.com/images/I/810YlRTqQeL.jpg', 2, 3, 2, 0),
(15, '2021-01-27 15:53:47', NULL, 'questo è un libro', 1, 'https://m.media-amazon.com/images/I/51vE9Yi4lHL.jpg', 1, 6, 1, 0),
(16, '2021-01-27 15:53:47', NULL, 'questo è un libro', 1, 'https://images-na.ssl-images-amazon.com/images/I/810ZsknSQQL.jpg', 1, 2, 1, 0),
(17, '2021-01-27 15:53:47', NULL, 'questo è un libro', 1, 'https://img.ibs.it/images/9788820071240_0_0_626_75.jpg', 2, 9, 2, 0),
(18, '2021-01-27 15:53:47', NULL, 'questo è un libro', 1, 'https://img.ibs.it/images/9788811816812_0_0_626_75.jpg', 2, 8, 2, 0),
(19, '2021-03-05 10:40:52', NULL, 'a', 0, 'https://www.adazing.com/wp-content/uploads/2019/02/open-book-clipart-03.png', 1, 1, 1, 1),
(20, '2021-03-05 10:53:58', NULL, 'aaaaa', 0, 'https://www.adazing.com/wp-content/uploads/2019/02/open-book-clipart-03.png', 1, 1, 1, 123231);

-- --------------------------------------------------------

--
-- Struttura della tabella `postpreferences`
--

CREATE TABLE `postpreferences` (
  `ID_user` int(11) NOT NULL,
  `ID_post` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `postview`
--

CREATE TABLE `postview` (
  `ID_user` int(11) NOT NULL,
  `ID_post` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `user`
--

CREATE TABLE `user` (
  `ID_user` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `birth_day` datetime NOT NULL,
  `mail` varchar(100) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `user`
--

INSERT INTO `user` (`ID_user`, `name`, `surname`, `birth_day`, `mail`, `telephone`, `sex`, `registration_date`) VALUES
(1, 'federico', 'nobile', '2021-01-18 10:57:03', 'fedenobile@gmail.com', '3298877654', 'maschio', '2021-01-23 09:59:01'),
(2, 'jayson', 'andal', '2021-01-22 10:57:03', 'jayson@gmail.com', '3456789993', 'maschio', '2021-01-23 09:59:01'),
(3, 'simone', 'ramello', '2000-01-02 10:57:03', 'simoneramello@gmail.com', '3668271992', 'maschio', '2021-01-27 15:49:53'),
(4, 'francesco', 'pistone', '2011-08-01 10:57:03', 'pistone@gmail.com', '3298877665', 'maschio', '2021-01-27 15:49:53'),
(5, 'gabriele', 'catalano', '2001-11-05 10:57:03', 'catalano@gmail.com', '3336667778', 'maschio', '2021-01-27 15:49:53'),
(6, 'gabriele', 'andrea', '1990-01-06 10:57:03', 'gabriele@gmail.com', '3476652431', 'maschio', '2021-01-27 15:49:53'),
(7, 'federico', 'candelo', '1999-08-12 10:57:03', 'candelo@gmail.com', '3298844321', 'maschio', '2021-01-27 15:49:53'),
(8, 'nicolo', 'taormina', '0000-00-00 00:00:00', 'taormina@gmail.com', '3338271623', 'maschio', '2021-01-27 15:49:53'),
(9, 'paolo', 'pasta', '2011-03-04 10:57:03', 'pasta@gmail.com', '3471655443', 'maschio', '2021-01-27 15:49:53');

-- --------------------------------------------------------

--
-- Struttura della tabella `userblock`
--

CREATE TABLE `userblock` (
  `ID_blocker` int(11) NOT NULL,
  `ID_blocked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`ID_book`),
  ADD KEY `ID_genre` (`ID_genre`);

--
-- Indici per le tabelle `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`ID_chat`),
  ADD KEY `ID_post` (`ID_post`);

--
-- Indici per le tabelle `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`ID_genre`);

--
-- Indici per le tabelle `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`ID_location`);

--
-- Indici per le tabelle `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`ID_message`),
  ADD KEY `ID_writer` (`ID_writer`),
  ADD KEY `ID_recepient` (`ID_recepient`),
  ADD KEY `ID_chat` (`ID_chat`);

--
-- Indici per le tabelle `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`ID_post`),
  ADD KEY `ID_creator` (`ID_creator`),
  ADD KEY `ID_book` (`ID_book`),
  ADD KEY `ID_location` (`ID_location`);

--
-- Indici per le tabelle `postpreferences`
--
ALTER TABLE `postpreferences`
  ADD PRIMARY KEY (`ID_user`,`ID_post`),
  ADD KEY `ID_post` (`ID_post`);

--
-- Indici per le tabelle `postview`
--
ALTER TABLE `postview`
  ADD PRIMARY KEY (`ID_user`,`ID_post`),
  ADD KEY `ID_user` (`ID_user`),
  ADD KEY `ID_post` (`ID_post`);

--
-- Indici per le tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID_user`);

--
-- Indici per le tabelle `userblock`
--
ALTER TABLE `userblock`
  ADD PRIMARY KEY (`ID_blocker`,`ID_blocked`),
  ADD KEY `ID_blocked` (`ID_blocked`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `book`
--
ALTER TABLE `book`
  MODIFY `ID_book` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `chat`
--
ALTER TABLE `chat`
  MODIFY `ID_chat` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `genre`
--
ALTER TABLE `genre`
  MODIFY `ID_genre` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT per la tabella `location`
--
ALTER TABLE `location`
  MODIFY `ID_location` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT per la tabella `message`
--
ALTER TABLE `message`
  MODIFY `ID_message` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `post`
--
ALTER TABLE `post`
  MODIFY `ID_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT per la tabella `user`
--
ALTER TABLE `user`
  MODIFY `ID_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`ID_genre`) REFERENCES `genre` (`ID_genre`);

--
-- Limiti per la tabella `chat`
--
ALTER TABLE `chat`
  ADD CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`ID_post`) REFERENCES `post` (`ID_post`);

--
-- Limiti per la tabella `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `message_ibfk_1` FOREIGN KEY (`ID_chat`) REFERENCES `chat` (`ID_chat`),
  ADD CONSTRAINT `message_ibfk_2` FOREIGN KEY (`ID_writer`) REFERENCES `user` (`ID_user`),
  ADD CONSTRAINT `message_ibfk_3` FOREIGN KEY (`ID_recepient`) REFERENCES `user` (`ID_user`);

--
-- Limiti per la tabella `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_ibfk_1` FOREIGN KEY (`ID_creator`) REFERENCES `user` (`ID_user`),
  ADD CONSTRAINT `post_ibfk_2` FOREIGN KEY (`ID_location`) REFERENCES `location` (`ID_location`),
  ADD CONSTRAINT `post_ibfk_3` FOREIGN KEY (`ID_book`) REFERENCES `book` (`ID_book`);

--
-- Limiti per la tabella `postpreferences`
--
ALTER TABLE `postpreferences`
  ADD CONSTRAINT `postpreferences_ibfk_1` FOREIGN KEY (`ID_post`) REFERENCES `post` (`ID_post`),
  ADD CONSTRAINT `postpreferences_ibfk_2` FOREIGN KEY (`ID_user`) REFERENCES `user` (`ID_user`);

--
-- Limiti per la tabella `postview`
--
ALTER TABLE `postview`
  ADD CONSTRAINT `postview_ibfk_1` FOREIGN KEY (`ID_user`) REFERENCES `user` (`ID_user`),
  ADD CONSTRAINT `postview_ibfk_2` FOREIGN KEY (`ID_post`) REFERENCES `post` (`ID_post`);

--
-- Limiti per la tabella `userblock`
--
ALTER TABLE `userblock`
  ADD CONSTRAINT `userblock_ibfk_1` FOREIGN KEY (`ID_blocker`) REFERENCES `user` (`ID_user`),
  ADD CONSTRAINT `userblock_ibfk_2` FOREIGN KEY (`ID_blocked`) REFERENCES `user` (`ID_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
